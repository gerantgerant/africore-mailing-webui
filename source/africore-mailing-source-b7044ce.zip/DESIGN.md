---
version: alpha
name: "Africore Mailing"
description: "A restrained mail-operations console that combines infrastructure clarity with Africore's burgundy identity."
colors:
  background: "#fffafb"
  foreground: "#231217"
  card: "#ffffff"
  content-background: "#fbf5f7"
  primary: "#6e0412"
  primary-foreground: "#fff7f8"
  secondary: "#f6e9ed"
  secondary-foreground: "#4c0b1b"
  muted: "#f2e9ec"
  muted-foreground: "#6a5a5f"
  accent: "#f6e2e8"
  accent-foreground: "#5b0b1f"
  border: "#e6d7dc"
  ring: "#a9193b"
  dark-background: "#140a0d"
  dark-card: "#1f1115"
  dark-primary: "#e15770"
  dark-muted-foreground: "#c6adb5"
typography:
  sans:
    fontFamily: "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif"
  mono:
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
rounded:
  DEFAULT: "0.5rem"
  sm: "0.25rem"
  md: "0.375rem"
  lg: "0.5rem"
  xl: "0.75rem"
spacing:
  page-gap: "1.5rem"
  card-gap: "1rem"
  control-height: "2.25rem"
components:
  button: {}
  card: {}
  sidebar: {}
  topbar: {}
  dashboard: {}
  form: {}
---

# Africore Mailing Design System

## Overview

### Creative North Star

The interface should feel like a well-run network operations desk with an Africore identity layer: high-signal controls, restrained surfaces, precise status language, and one distinctive burgundy signature taken from the Africore Mailing logo. It is not a marketing site.

### Product context and register

- **Audience and primary job:** administrators operating domains, mail accounts, queues, configuration, and account access without losing sight of current server state.
- **Target market(s) and evidence:** the product is being deployed for Africore's own mail infrastructure; visual choices come from the approved Africore Mailing burgundy logo, not from assumptions about geography.
- **Locale(s) and language policy:** preserve the application's existing i18n mechanism and English fallback strings; added copy must go through `react-i18next`.
- **Usage scene:** desktop-first administration with occasional narrow-screen access, repeated operational use, and moderate information density.
- **Register:** product UI. Brand expression belongs in the logo, primary action/focus color, and dashboard header rather than decorative backgrounds.
- **Memorable signature:** the Africa-envelope Africore Mailing mark paired with deep burgundy `#6e0412`.
- **Restraint:** forms, destructive actions, permissions, tables, and error states keep familiar admin patterns and semantic colors.
- **Anti-references:** no glassmorphism, loud gradients, promotional Enterprise banners, decorative charts without real data, or red-on-red status ambiguity.
- **Token ownership/runtime mapping:** `src/index.css` remains the runtime source of truth. This document mirrors the approved values and must change with the runtime tokens when the visual system changes.

## Colors

The light theme uses warm near-white infrastructure surfaces with deep burgundy as the primary action and focus color. The dark theme shifts the primary to `#e15770` so controls remain legible on near-black burgundy surfaces. Destructive red remains semantically separate from the brand color. Muted text must retain WCAG AA contrast for ordinary text.

## Typography

Keep the existing system sans-serif stack for low-latency administration and broad platform coverage. Use medium or semibold weight for headings and status values; body copy remains regular. Technical identifiers can use the system monospace stack when an existing component calls for it. Avoid all-caps except short eyebrow labels with increased tracking.

## Layout

Preserve the existing 56px top bar, 256px desktop sidebar, and compact form/list density. Dashboard cards use the existing responsive grid primitives rather than introducing a second layout system. Narrow screens stack content without hiding actions. Loading and error states reserve enough height to avoid control movement.

## Elevation & Depth

Use borders and tonal surface changes as the primary hierarchy mechanism. Static operational cards should not use strong shadows. Dialogs and menus may retain the project's existing overlay elevation. Burgundy-tinted dashboard headers are subtle (`primary` at low opacity), not promotional banners.

## Shapes

Keep the existing 0.5rem radius family for controls and cards. Larger dashboard groups may use 0.75rem. Avoid pill-shaped structural containers; reserve pills for compact badges or status indicators already established by the project.

## Components

### Foundational visual states

Interactive elements must expose hover, focus-visible, disabled, busy, success, and error states through existing shared primitives. The ring token is burgundy in light mode and a brighter rose-burgundy in dark mode. Loading uses the project's existing `Loader2` spinner and never substitutes invented values.

### Buttons and actions

Primary actions use the primary token; destructive actions continue using the destructive token. Icon-only actions require accessible labels. Busy actions keep their geometry. Enterprise upsell actions are intentionally absent from Africore Mailing.

### Navigation and data display

Top bar and sidebar retain their existing geometry and shared navigation components. Enterprise-only links are removed for non-Enterprise editions rather than displayed as locked promotions. The community dashboard shows only counters that the current account can query and explicitly marks unavailable totals.

### Forms and overlays

Reuse the existing Radix-based inputs, selects, dialogs, tooltips, and alert dialogs. Enterprise-only fields are omitted when the running edition cannot use them; they are not shown disabled with a sales tooltip.

### Iconography

Use Lucide icons with the existing stroke treatment. Operational cards use 16px icons; major status values may use 24px indicators. Text labels remain present for actions whose meaning is not universal.

### Motion

Motion communicates state only: spinner rotation, disclosure transitions, menu/dialog behavior, and existing short transitions. Do not add decorative animation. Respect reduced-motion behavior provided by browser and shared primitives.

### Content and data visualization

Voice is concise and operational. Counts use locale-aware number formatting. The dashboard may only display data returned by standard management/JMAP APIs available to the current account. Historical Enterprise telemetry is neither requested nor simulated.

## Do's and Don'ts

- **Do:** use burgundy as a focused identity signal while preserving semantic status colors.
- **Do:** show explicit unavailable/error states when management data cannot be read.
- **Don't:** show Enterprise activation, trial, license purchase, or locked-feature promotions in Africore Mailing.
- **Don't:** fabricate charts, queue counts, service health, or delivery metrics that the server did not report.

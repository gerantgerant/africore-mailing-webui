/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

export function isEnterpriseFeatureAvailable(isEnterprise: boolean, edition: string): boolean {
  return !isEnterprise || edition === 'enterprise';
}

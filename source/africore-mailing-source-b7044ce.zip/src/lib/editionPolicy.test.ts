/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { describe, expect, it } from 'vitest';
import { isEnterpriseFeatureAvailable } from './editionPolicy';

describe('isEnterpriseFeatureAvailable', () => {
  it('keeps normal features available in every edition', () => {
    expect(isEnterpriseFeatureAvailable(false, 'oss')).toBe(true);
    expect(isEnterpriseFeatureAvailable(false, 'community')).toBe(true);
    expect(isEnterpriseFeatureAvailable(false, 'enterprise')).toBe(true);
  });

  it('hides enterprise-only features from OSS and Community', () => {
    expect(isEnterpriseFeatureAvailable(true, 'oss')).toBe(false);
    expect(isEnterpriseFeatureAvailable(true, 'community')).toBe(false);
  });

  it('keeps enterprise-only features available to Enterprise', () => {
    expect(isEnterpriseFeatureAvailable(true, 'enterprise')).toBe(true);
  });
});

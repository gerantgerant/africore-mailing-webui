/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { describe, expect, it } from 'vitest';
import type { Schema } from '@/types/schema';
import { isLinkAccessible, isLinkEnterprise, isLinkVisible } from './layout';

const schema: Schema = {
  objects: {
    'x:EnterpriseFeature': {
      type: 'object',
      description: 'Enterprise-only feature',
      permissionPrefix: 'sysEnterpriseFeature',
      enterprise: true,
    },
  },
  schemas: {},
  fields: {},
  forms: {},
  lists: {},
  enums: {},
  dashboards: [],
  layouts: [],
};

const canGetEverything = () => true;
const hasNoEnterprisePermissions = () => false;

describe('Africore community navigation policy', () => {
  it.each(['community', 'oss'])('keeps the custom dashboard accessible in %s edition', (edition) => {
    expect(
      isLinkVisible(schema, 'CustomComponent/Dashboard', edition, canGetEverything, hasNoEnterprisePermissions),
    ).toBe(true);
    expect(isLinkEnterprise(schema, 'CustomComponent/Dashboard', edition)).toBe(false);
    expect(
      isLinkAccessible(schema, 'CustomComponent/Dashboard', edition, canGetEverything, hasNoEnterprisePermissions),
    ).toBe(true);
  });

  it('hides enterprise-only object links in community instead of exposing a locked upsell', () => {
    expect(
      isLinkVisible(schema, 'x:EnterpriseFeature', 'community', canGetEverything, hasNoEnterprisePermissions),
    ).toBe(false);
    expect(
      isLinkAccessible(schema, 'x:EnterpriseFeature', 'community', canGetEverything, hasNoEnterprisePermissions),
    ).toBe(false);
  });

  it('keeps enterprise-only object links available to enterprise editions', () => {
    expect(
      isLinkVisible(schema, 'x:EnterpriseFeature', 'enterprise', canGetEverything, hasNoEnterprisePermissions),
    ).toBe(true);
  });
});

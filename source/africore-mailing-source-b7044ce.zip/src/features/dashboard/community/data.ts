/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { getAccountId, jmapQuery } from '@/services/jmap/client';
import type { JmapQueryResponse } from '@/types/jmap';
import type { CommunityDashboardResource } from './model';

export async function fetchCommunityResourceTotal(resource: CommunityDashboardResource): Promise<number | null> {
  const accountId = getAccountId(resource.objectName);
  const responses = await jmapQuery(resource.objectName, accountId, {
    filter: resource.filter,
    limit: 1,
    calculateTotal: true,
  });

  const response = responses[0];
  if (!response) return null;

  if (response[0] === 'error' || response[0].endsWith('/error')) {
    const type = (response[1] as Record<string, unknown>).type;
    throw new Error(typeof type === 'string' ? type : 'JMAP query failed');
  }

  const data = response[1] as unknown as JmapQueryResponse;
  return typeof data.total === 'number' ? data.total : null;
}

/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { resolveObject } from '@/lib/schemaResolver';
import type { Schema } from '@/types/schema';

export interface CommunityDashboardResource {
  id: 'domains' | 'mail-accounts' | 'queued-messages';
  label: string;
  viewName: string;
  objectName: string;
  filter?: Record<string, unknown>;
}

const RESOURCE_CANDIDATES: Array<Pick<CommunityDashboardResource, 'id' | 'label' | 'viewName'>> = [
  { id: 'domains', label: 'Domains', viewName: 'x:Domain' },
  { id: 'mail-accounts', label: 'Mail accounts', viewName: 'x:Account/User' },
  { id: 'queued-messages', label: 'Queued messages', viewName: 'x:QueuedMessage' },
];

export function getCommunityDashboardResources(
  schema: Schema,
  hasPermission: (permission: string) => boolean,
): CommunityDashboardResource[] {
  return RESOURCE_CANDIDATES.flatMap((candidate) => {
    const resolved = resolveObject(schema, candidate.viewName);
    if (!resolved || resolved.enterprise) return [];

    if (!hasPermission(`${resolved.permissionPrefix}Get`) || !hasPermission(`${resolved.permissionPrefix}Query`)) {
      return [];
    }

    const filter = schema.lists[candidate.viewName]?.filtersStatic;
    return [
      {
        ...candidate,
        objectName: resolved.objectName,
        filter,
      },
    ];
  });
}

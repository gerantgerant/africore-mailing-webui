/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { CommunityDashboardResource } from './model';

const { jmapQuery, getAccountId } = vi.hoisted(() => ({
  jmapQuery: vi.fn(),
  getAccountId: vi.fn(() => 'primary-account'),
}));

vi.mock('@/services/jmap/client', () => ({
  jmapQuery,
  getAccountId,
}));

import { fetchCommunityResourceTotal } from './data';

const resource: CommunityDashboardResource = {
  id: 'mail-accounts',
  label: 'Mail accounts',
  viewName: 'x:Account/User',
  objectName: 'x:Account',
  filter: { role: 'user' },
};

describe('fetchCommunityResourceTotal', () => {
  beforeEach(() => {
    jmapQuery.mockReset();
    getAccountId.mockClear();
  });

  it('uses a standard JMAP query with calculateTotal and the view filter', async () => {
    jmapQuery.mockResolvedValue([['x:Account/query', { accountId: 'primary-account', ids: ['a'], total: 7 }, '0']]);

    await expect(fetchCommunityResourceTotal(resource)).resolves.toBe(7);
    expect(getAccountId).toHaveBeenCalledWith('x:Account');
    expect(jmapQuery).toHaveBeenCalledWith('x:Account', 'primary-account', {
      filter: { role: 'user' },
      limit: 1,
      calculateTotal: true,
    });
  });

  it('returns null instead of inventing a count when total is missing', async () => {
    jmapQuery.mockResolvedValue([['x:Account/query', { accountId: 'primary-account', ids: ['a'] }, '0']]);

    await expect(fetchCommunityResourceTotal(resource)).resolves.toBeNull();
  });

  it('throws on a JMAP error so the dashboard can show an explicit unavailable state', async () => {
    jmapQuery.mockResolvedValue([['error', { type: 'forbidden' }, '0']]);

    await expect(fetchCommunityResourceTotal(resource)).rejects.toThrow('forbidden');
  });
});

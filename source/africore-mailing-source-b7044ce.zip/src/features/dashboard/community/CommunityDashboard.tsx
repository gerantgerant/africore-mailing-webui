/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, Globe2, Loader2, Mail, RefreshCw, Server, Users } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAccountStore } from '@/stores/accountStore';
import { useSchemaStore } from '@/stores/schemaStore';
import { fetchCommunityResourceTotal } from './data';
import { getCommunityDashboardResources, type CommunityDashboardResource } from './model';

type ResourceStatus = 'loading' | 'ready' | 'unavailable' | 'error';

interface ResourceState {
  status: ResourceStatus;
  value: number | null;
}

const RESOURCE_ICONS = {
  domains: Globe2,
  'mail-accounts': Users,
  'queued-messages': Mail,
} as const;

export function CommunityDashboard() {
  const { t } = useTranslation();
  const schema = useSchemaStore((state) => state.schema);
  const permissions = useAccountStore((state) => state.permissions);
  const locale = useAccountStore((state) => state.locale);
  const requestId = useRef(0);
  const [resourceStates, setResourceStates] = useState<Record<string, ResourceState>>({});
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const resources = useMemo(() => {
    if (!schema) return [];
    const permissionSet = new Set(permissions);
    return getCommunityDashboardResources(schema, (permission) => permissionSet.has(permission));
  }, [schema, permissions]);

  const load = useCallback(async () => {
    const currentRequest = ++requestId.current;
    const results = await Promise.all(
      resources.map(async (resource) => {
        try {
          const value = await fetchCommunityResourceTotal(resource);
          return [
            resource.id,
            { status: value === null ? 'unavailable' : 'ready', value } satisfies ResourceState,
          ] as const;
        } catch {
          return [resource.id, { status: 'error', value: null } satisfies ResourceState] as const;
        }
      }),
    );

    if (requestId.current !== currentRequest) return;
    setResourceStates(Object.fromEntries(results));
    setLastUpdated(new Date());
  }, [resources]);

  useEffect(() => {
    void load();
    return () => {
      requestId.current += 1;
    };
  }, [load]);

  const numberFormatter = useMemo(() => new Intl.NumberFormat(locale || undefined), [locale]);

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-xl border bg-card">
        <div className="border-b bg-primary/[0.06] px-6 py-6 dark:bg-primary/[0.12]">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                {t('africore.dashboard.eyebrow', 'Mail infrastructure')}
              </p>
              <h1 className="text-2xl font-semibold tracking-tight">
                {t('africore.dashboard.title', 'Africore Mailing')}
              </h1>
              <p className="max-w-2xl text-sm text-muted-foreground">
                {t(
                  'africore.dashboard.subtitle',
                  'Operational overview built from the management data available on this server.',
                )}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => void load()}>
              <RefreshCw className="mr-2 h-4 w-4" />
              {t('common.refresh', 'Refresh')}
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 px-6 py-3 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5 text-foreground">
            <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
            {t('africore.dashboard.managementConnected', 'Management session connected')}
          </span>
          {lastUpdated && (
            <span>
              {t('africore.dashboard.lastUpdated', 'Last updated')}{' '}
              {new Intl.DateTimeFormat(locale || undefined, {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              }).format(lastUpdated)}
            </span>
          )}
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('africore.dashboard.adminApi', 'Admin API')}</CardTitle>
            <Server className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">{t('common.connected', 'Connected')}</div>
            <p className="mt-1 text-xs text-muted-foreground">
              {t('africore.dashboard.adminApiHint', 'Authenticated management session')}
            </p>
          </CardContent>
        </Card>

        {resources.map((resource) => (
          <ResourceCard
            key={resource.id}
            resource={resource}
            state={resourceStates[resource.id] ?? { status: 'loading', value: null }}
            formatNumber={(value) => numberFormatter.format(value)}
          />
        ))}
      </div>

      {resources.length === 0 && (
        <div className="flex items-start gap-3 rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            {t(
              'africore.dashboard.noReadableResources',
              'No additional counters are available for this account. The dashboard will not display data you are not allowed to read.',
            )}
          </p>
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        {t(
          'africore.dashboard.scopeNote',
          'Counts come from standard JMAP management queries. Historical telemetry is intentionally not requested.',
        )}
      </p>
    </div>
  );
}

function ResourceCard({
  resource,
  state,
  formatNumber,
}: {
  resource: CommunityDashboardResource;
  state: ResourceState;
  formatNumber: (value: number) => string;
}) {
  const { t } = useTranslation();
  const Icon = RESOURCE_ICONS[resource.id];

  let value: React.ReactNode;
  let hint: string;
  if (state.status === 'loading') {
    value = <Loader2 className="h-6 w-6 animate-spin text-primary" aria-label={t('common.loading', 'Loading')} />;
    hint = t('africore.dashboard.loadingCounter', 'Reading server data');
  } else if (state.status === 'ready' && state.value !== null) {
    value = formatNumber(state.value);
    hint = t('africore.dashboard.currentCount', 'Current count');
  } else if (state.status === 'unavailable') {
    value = '—';
    hint = t('africore.dashboard.notReported', 'Total not reported by the server');
  } else {
    value = t('common.unavailable', 'Unavailable');
    hint = t('africore.dashboard.queryFailed', 'Could not read this counter');
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{resource.label}</CardTitle>
        <Icon className="h-4 w-4 text-primary" />
      </CardHeader>
      <CardContent>
        <div className="min-h-8 text-2xl font-semibold">{value}</div>
        <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
      </CardContent>
    </Card>
  );
}

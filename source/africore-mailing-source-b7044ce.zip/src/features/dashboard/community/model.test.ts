/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { describe, expect, it } from 'vitest';
import type { Schema } from '@/types/schema';
import { getCommunityDashboardResources } from './model';

const schema: Schema = {
  objects: {
    'x:Domain': { type: 'object', description: 'Mail domain', permissionPrefix: 'sysDomain' },
    'x:Account': { type: 'object', description: 'Account', permissionPrefix: 'sysAccount' },
    'x:Account/User': { type: 'view', objectName: 'x:Account' },
    'x:QueuedMessage': { type: 'object', description: 'Queued message', permissionPrefix: 'sysQueue' },
    'x:Tenant': {
      type: 'object',
      description: 'Tenant',
      permissionPrefix: 'sysTenant',
      enterprise: true,
    },
  },
  schemas: {},
  fields: {},
  forms: {},
  lists: {
    'x:Domain': {
      title: 'Domains',
      subtitle: '',
      singularName: 'domain',
      pluralName: 'domains',
      columns: [],
    },
    'x:Account/User': {
      title: 'Users',
      subtitle: '',
      singularName: 'user',
      pluralName: 'users',
      columns: [],
      filtersStatic: { role: 'user' },
    },
    'x:QueuedMessage': {
      title: 'Queue',
      subtitle: '',
      singularName: 'message',
      pluralName: 'messages',
      columns: [],
    },
  },
  enums: {},
  dashboards: [],
  layouts: [],
};

describe('getCommunityDashboardResources', () => {
  it('returns only safe, readable community resources and preserves view filters', () => {
    const permissions = new Set(['sysDomainGet', 'sysDomainQuery', 'sysAccountGet', 'sysAccountQuery']);
    const resources = getCommunityDashboardResources(schema, (permission) => permissions.has(permission));

    expect(resources).toEqual([
      {
        id: 'domains',
        label: 'Domains',
        viewName: 'x:Domain',
        objectName: 'x:Domain',
        filter: undefined,
      },
      {
        id: 'mail-accounts',
        label: 'Mail accounts',
        viewName: 'x:Account/User',
        objectName: 'x:Account',
        filter: { role: 'user' },
      },
    ]);
  });

  it('includes the mail queue only when both read and query permissions are present', () => {
    const resources = getCommunityDashboardResources(schema, (permission) =>
      ['sysQueueGet', 'sysQueueQuery'].includes(permission),
    );

    expect(resources.map((resource) => resource.id)).toEqual(['queued-messages']);
  });

  it('never exposes enterprise-only resources', () => {
    const resources = getCommunityDashboardResources(schema, () => true);
    expect(resources.some((resource) => resource.objectName === 'x:Tenant')).toBe(false);
  });
});

/*
 * SPDX-FileCopyrightText: 2020 Stalwart Labs LLC <hello@stalw.art>
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-SEL
 */

import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { DefaultLogo } from './Logo';

describe('Africore Mailing branding', () => {
  it('uses Africore Mailing as the default accessible identity', () => {
    const html = renderToStaticMarkup(<DefaultLogo />);

    expect(html).toContain('Africore Mailing');
    expect(html).not.toContain('Stalwart Logo');
  });
});
